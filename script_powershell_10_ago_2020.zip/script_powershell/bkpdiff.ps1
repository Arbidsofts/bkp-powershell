﻿## ########################################
## Name: bkpdiff.ps1
## Creator: Luziney Arbid Luz
## Company: Arbidsofts Ltda
## Email: suporte@arbidsofts.net
## Copyright (c) 2020 - All Right Reserved
## Version: 2.0
## CreationDate: 05/08/2020
## LastModified: 10/08/2020
## ########################################

## SCRIPT DE BACKUP DIFERENCIAL
## Windows PowerShell ISE

#####  A T E N Ç Ã O  #####
##
## ITENS QUE NÃO DEVEM SER ALTERADOS.
##
#####  A T E N Ç Ã O  #####

## Configura os aplicativos usados no Backup (7zip).
set-alias 7z "C:\Windows\7z.exe"

## Formato da Data e Hora.
$DATA = Get-Date -Format yyy.MM.dd-HH.mm.ss

#####  A T E N Ç Ã O  #####
##
## Os itens abaixo devem ser alterados para cada Backup Completo que será realizado.
##
#####  A T E N Ç Ã O  #####

## Configura a UNIDADE de destino do backup.
$UDST = "D:"

## Configura o nome do CLIENTE do Backup.
$CLI = "ARBIDSOFTS"

## Configura o NOME da PASTA Origem do Backup e adiciona ao NOME do Arquivo de Backup. Crie uma linha para cada PASTA.
$PST0 = "FINANCEIRO"
$PST1 = "PROJETOS"

## Configura a PASTA Origem do Backup. Crie uma linha para cada PASTA.
$ORG0 = "$UDST\$PST0\"
$ORG1 = "$UDST\$PST1\"

## NOME do Arquivo de Backup. Crie uma linha para cada PASTA.
$NOM0 = "BKP.DIFF.$CLI.$PST0.$DATA.zip"
$NOM1 = "BKP.DIFF.$CLI.$PST1.$DATA.zip"

## Destino do Backup Diferencial. Crie uma linha para cada PASTA.
$DST0 = "$UDST\BKP_DIFF\"

## Configura a PASTA destino do arquivo de LOG.
$LOGDST = "$UDST\BKP_LOGS\"

## Configura o NOME do arquivo de LOG. Crie uma linha para cada PASTA.
$LOG0 = "$LOGDST\LOG.DIFF.$CLI.$PST0.$DATA.txt"
$LOG1 = "$LOGDST\LOG.DIFF.$CLI.$PST1.$DATA.txt"

## PASTA do Backup Completo. Crie uma linha para cada PASTA.
$BF0 = "$UDST\BK_FULL\"

##  Configura o NOME do arquivo de Backup Completo a ser localizado.
$FA0 = $BF0 + "*" + $PST0 + "*"
$FA1 = $BF0 + "*" + $PST1 + "*"

##  Localiza último arquivo de Backup Completo como base para o Backup Diferencial. Crie uma linha para cada ARQUIVO.
$LOC0 = Get-ChildItem $FA0 | Sort-Object LastAccessTime | select -Last 1
$LOC1 = Get-ChildItem $FA1 | Sort-Object LastAccessTime | select -Last 1

##  Argumentos do 7zip. Crie uma linha para cada PASTA.
$ARG0 = '-u-', "-up0q0r2x2y2z0w2!`"$($DST0)$($NOM0)`""
$ARG1 = '-u-', "-up0q0r2x2y2z0w2!`"$($DST0)$($NOM1)`""

##  Linha de comando para gerar o Backup. Crie uma linha para cada PASTA.
7z u $LOC0 $ORG0 $ARG0 > $LOG0
7z u $LOC1 $ORG1 $ARG1 > $LOG1

##  Fim das instruções para GERAR o backup.

#####  A T E N Ç Ã O  #####
##
##  Início das instruções para envio da mensagem por e-mail.
##
#####  A T E N Ç Ã O  #####

## SCRIPT PARA ENVIAR E-MAIL AO FINAL DO BACKUP DIFERENCIAL
## Windows PowerShell ISE

##  Configurações do servidor SMTP da conta de email.
$SRV = "smtp.arbidsofts.net"
$PRT = "587"
$FRM = "no-reply@arbidsofts.net"
$PWD = "171450As#"

##  Configuções do e-mail.

## DESTINATÁRIO
$TO = "suporte@arbidsofts.net"

## DESTINATÁRIO CÓPIA (CC)
$CC = "arbidsofts@yahoo.com"

## DESTINATÁRIO CÓPIA OCULTA (BCC)
$BCC = "guloseimascaseiras@gmail.com"

## ASSUNTO
$SUB = "[$CLI] Conclusão do Backup"

## CORPO
$BDY = Get-Content "$UDST\SCRIPTS\msgfull.html" -Raw

## ANEXO :: Crie uma linha para cada ARQUIVO.
$ATT0 = $LOG0
$ATT1 = $LOG1

## Configuração do envio do e-mail.
$Message = New-Object System.Net.Mail.MailMessage
$Message.Subject = $SUB
$Message.Body = $BDY
$Message.IsBodyHtml = $BDY
$Message.To.Add($TO)
$Message.CC.Add($CC)
$Message.BCC.Add($BCC)
$Message.From = $FRM.Replace("=", "@") ## Para provedores que usam = em vez de @ para identificar o nome de usuário.

## ANEXO :: Crie uma linha para cada ARQUIVO.
$attachment1 = new-object Net.Mail.Attachment($ATT0)
$message.attachments.add($attachment1)

$attachment2 = new-object Net.Mail.Attachment($ATT1)
$message.attachments.add($attachment2)

$SMTP = New-Object System.Net.Mail.SmtpClient($SRV, $PRT);
$SMTP.EnableSSL = $false # Caso você utilize 'Gmail', troque essa variável "$false" por "$true".
$SMTP.Credentials = New-Object System.Net.NetworkCredential($FRM, $PWD);
$SMTP.Send($Message)

Write-Host "Pronto!"

##  FIM DO ARQUIVO.